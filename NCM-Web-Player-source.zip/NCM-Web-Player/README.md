# NCM Lite Web — iPhone Safari 网页播放器

基于浏览器的轻量播放器原型，目标是在 iPhone Safari 打开，并可“添加到主屏幕”。它不是 IPA，也不是对 `api-enhanced` 后端的移植。

## 下载与运行

网页需要通过 HTTPS 或 localhost 提供服务，直接双击 `index.html` 可能无法启用 PWA。可将此目录部署到任意支持静态网页的 HTTPS 托管平台（例如 GitHub Pages、Cloudflare Pages 等），再在 iPhone Safari 打开网址。

### 重要的后端限制

你提供的 `api-enhanced` 是 Node.js API 服务，普通 iPhone Safari 不能直接运行这个 Node.js 服务。因此，播放器还需要一个可访问的 API 地址：

- 在网页右上角 ⚙ 设置中填写 API 服务 URL，例如 `https://你的-api-域名`。
- API 服务必须已部署并允许网页跨域访问（CORS）。
- 如果你目前只有 iPhone、没有电脑/NAS/服务器，那么此版本**不能独立搜索网易云音乐**。可以把静态网页托管在 HTTPS 平台，但这只托管网页本身，不会自动运行 Node.js 后端。
- API 使用 HTTP 时，HTTPS 网页可能会被浏览器阻止混合内容，推荐后端也启用 HTTPS。
- 歌曲播放地址受版权、地区、登录状态及上游 API 可用性影响；不保证所有歌曲可播放。

## 已实现

- 简洁暗色响应式界面
- 搜索歌曲：`/search?keywords=...&type=1`
- 获取播放地址：`/song/url/v1?id=...&level=standard`
- 获取歌词：`/lyric?id=...`
- HTML5 Audio 播放/暂停、进度条、时长显示
- 保存 API 地址到浏览器本地存储
- 基础 PWA manifest/service worker，支持添加到主屏幕（需要 HTTPS）

## 尚未实现

- 不包含 Node.js 后端，不会在 iPhone 本地运行 `api-enhanced`
- 未做网易云账号登录、Cookie、VIP/版权解锁
- 无播放列表、随机/循环/上一首/下一首
- 歌词目前显示原始 LRC 文本，不做逐行时间同步
- 无离线音乐下载
- iOS 后台音频行为受 Safari/PWA 限制，尚未做原生后台播放集成
- 未在真机/各浏览器完成测试

## API 部署参考

按上游项目 README 的 Node.js 版本与启动步骤部署后端。不要把 Cookie、密码或 token 写进公开网页源码。生产使用建议用 HTTPS、设置访问控制并避免把未受保护的服务暴露在公网。

上游项目：
https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced
