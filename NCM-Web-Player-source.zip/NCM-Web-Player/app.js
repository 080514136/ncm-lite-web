const $ = (id) => document.getElementById(id);
const audio = $("audio");
const state = { base: localStorage.getItem("ncmApiBase") || "", songs: [], current: null, expanded: false };

function setNotice(text, error = false) {
  $("notice").textContent = text;
  $("notice").classList.toggle("error", error);
}
function cleanBase(value) { return value.trim().replace(/\/+$/, ""); }
function apiURL(path, params = {}) {
  if (!state.base) throw new Error("请先点击右上角设置，填写 API 服务地址。");
  const url = new URL(state.base + path);
  Object.entries(params).forEach(([k,v]) => url.searchParams.set(k, v));
  return url;
}
async function api(path, params) {
  let response;
  try { response = await fetch(apiURL(path, params)); }
  catch (e) { throw new Error("无法连接 API。请检查地址、网络和服务器跨域（CORS）设置。"); }
  if (!response.ok) throw new Error(`API 请求失败（HTTP ${response.status}）。`);
  return response.json();
}
function artistNames(song) {
  const list = song.artists || song.ar || song.artists || [];
  return list.map(x => x.name).filter(Boolean).join(" / ") || "未知歌手";
}
function albumName(song) { return (song.album || song.al || {}).name || ""; }
function renderSongs() {
  $("resultCount").textContent = `${state.songs.length} 首`;
  const root = $("results");
  root.replaceChildren();
  if (!state.songs.length) {
    root.innerHTML = '<div class="empty"><div class="empty-note">♫</div><p>没有找到歌曲</p><small>试试其他关键词</small></div>';
    return;
  }
  state.songs.forEach((song, index) => {
    const button = document.createElement("button");
    button.className = "song" + (state.current?.id === song.id ? " selected" : "");
    button.innerHTML = `<span class="song-number">${String(index + 1).padStart(2,"0")}</span><span class="song-main"><span class="song-title"></span><span class="song-sub"></span></span><span class="song-play">▶</span>`;
    button.querySelector(".song-title").textContent = song.name || "未知歌曲";
    button.querySelector(".song-sub").textContent = `${artistNames(song)}${albumName(song) ? " · " + albumName(song) : ""}`;
    button.addEventListener("click", () => playSong(song));
    root.append(button);
  });
}
async function searchSongs(event) {
  event?.preventDefault();
  const keyword = $("keyword").value.trim();
  if (!keyword) return;
  $("searchButton").disabled = true;
  setNotice("正在搜索…");
  try {
    const data = await api("/search", {keywords: keyword, type: "1"});
    state.songs = data.result?.songs || data.songs || [];
    renderSongs();
    setNotice(state.songs.length ? `找到 ${state.songs.length} 首歌曲。点击歌曲即可播放。` : "没有搜索到结果。");
  } catch (error) {
    state.songs = []; renderSongs(); setNotice(error.message, true);
  } finally { $("searchButton").disabled = false; }
}
function lyricText(data) {
  return data.lrc?.lyric || data.lyric || data.tlyric?.lyric || "暂无歌词";
}
async function playSong(song) {
  state.current = song;
  $("trackName").textContent = song.name || "未知歌曲";
  $("trackArtist").textContent = artistNames(song);
  $("playPause").disabled = true;
  $("playPause").textContent = "…";
  $("lyrics").textContent = "正在加载歌词…";
  renderSongs();
  setNotice("正在获取播放地址…");
  try {
    const [urlData, lyricData] = await Promise.all([
      api("/song/url/v1", {id: song.id, level: "standard"}),
      api("/lyric", {id: song.id})
    ]);
    const streamURL = urlData.data?.[0]?.url;
    $("lyrics").textContent = lyricText(lyricData);
    if (!streamURL) throw new Error("没有可用播放地址。这首歌可能受版权、地区或登录状态限制。");
    audio.src = streamURL;
    audio.load();
    await audio.play();
    $("playPause").disabled = false;
    $("playPause").textContent = "Ⅱ";
    setNotice("正在播放。");
  } catch (error) {
    $("playPause").disabled = false;
    $("playPause").textContent = "▶";
    setNotice(error.message || "播放失败。", true);
  }
}
$("searchForm").addEventListener("submit", searchSongs);
$("playPause").addEventListener("click", async () => {
  if (!audio.src) return;
  if (audio.paused) {
    try { await audio.play(); } catch { setNotice("播放失败，请重新选择歌曲。", true); }
  } else audio.pause();
});
audio.addEventListener("play", () => $("playPause").textContent = "Ⅱ");
audio.addEventListener("pause", () => $("playPause").textContent = "▶");
audio.addEventListener("loadedmetadata", () => {
  $("duration").textContent = fmt(audio.duration);
  $("seek").disabled = false;
});
audio.addEventListener("timeupdate", () => {
  $("currentTime").textContent = fmt(audio.currentTime);
  if (Number.isFinite(audio.duration) && audio.duration > 0)
    $("seek").value = String(Math.round(audio.currentTime / audio.duration * 1000));
});
audio.addEventListener("ended", () => $("playPause").textContent = "▶");
audio.addEventListener("error", () => { if (audio.src) setNotice("音频无法播放：可能是地址失效、跨域或资源限制。", true); });
$("seek").addEventListener("input", () => {
  if (Number.isFinite(audio.duration)) audio.currentTime = audio.duration * Number($("seek").value) / 1000;
});
function fmt(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const s = Math.max(0, Math.floor(seconds));
  return `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
}
$("toggleLyrics").addEventListener("click", () => {
  state.expanded = !state.expanded;
  $("lyrics").classList.toggle("expanded", state.expanded);
  $("toggleLyrics").textContent = state.expanded ? "收起" : "展开";
});
$("settingsOpen").addEventListener("click", () => {
  $("apiBase").value = state.base;
  $("settingsStatus").textContent = "";
  $("settingsDialog").showModal();
});
$("settingsForm").addEventListener("submit", async (event) => {
  if (event.submitter?.value === "cancel") return;
  event.preventDefault();
  const value = cleanBase($("apiBase").value);
  try {
    new URL(value);
    state.base = value;
    localStorage.setItem("ncmApiBase", value);
    $("settingsStatus").textContent = "已保存。正在测试搜索接口…";
    await api("/search", {keywords: "周杰伦", type: "1"});
    $("settingsStatus").textContent = "连接成功！你可以开始搜索歌曲。";
    setNotice("API 已连接，可以搜索歌曲。");
    setTimeout(() => $("settingsDialog").close(), 800);
  } catch (error) {
    $("settingsStatus").textContent = error.message || "地址格式无效。";
  }
});
if (state.base) setNotice("已保存 API 地址。输入关键词即可搜索；若连接失败请检查服务器。");
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}
